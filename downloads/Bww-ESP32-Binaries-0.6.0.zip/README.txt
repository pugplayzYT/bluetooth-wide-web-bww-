BWW ESP32 firmware 0.6.0

For original ESP32 with Bluetooth Classic and at least 4 MB flash.
This build uses the BWW huge_app partition layout and GPIO5/18/23/19 SD wiring.

UPGRADE an existing BWW 0.4.x/0.5.x/0.6.x ESP32:
Back up the SD card /bww folder first. Firmware 0.6.0 migrates the website index
without formatting. Do not downgrade to 0.5.2 or earlier after migration.
Install Android 0.6.0 to list all sites when there are more than 32.

1. Extract this ZIP. Close PlatformIO's serial monitor so COM3 is free.
2. Open PowerShell in the extracted folder. Change COM3 below if needed.
3. With your existing PlatformIO installation, run:

& "$env:USERPROFILE\.platformio\penv\Scripts\python.exe" "$env:USERPROFILE\.platformio\packages\tool-esptoolpy\esptool.py" --chip esp32 --port COM3 write_flash 0x10000 .\firmware.bin

This writes only the application and does not erase flash or format the SD card.
If connection stalls, hold BOOT while connecting; release when writing starts.
Afterward restart the serial monitor at 115200 and confirm firmware 0.6.0.

A fresh board requires its bootloader/partition/OTA-selection files as well:
python -m esptool --chip esp32 --port COM3 write_flash 0x1000 bootloader.bin 0x8000 partitions.bin 0xe000 boot_app0.bin 0x10000 firmware.bin
Use a Python environment with esptool 4.5.1. This full-layout command is for the
original ESP32/4 MB board above; prefer the PlatformIO source ZIP for custom boards.

firmware.elf is the matching crash-decoder file, not a file to flash.
For a prebuilt-image install, copy it to your PlatformIO project's
.pio/build/esp32dev/firmware.elf and use monitor_filters = esp32_exception_decoder.
Do not substitute an ELF from another build.

Physical Bluetooth/SD-card validation remains necessary; see VALIDATION.md.
